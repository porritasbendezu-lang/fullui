# 🎨 FULLUI — Console UI System

> Build beautiful, interactive terminal apps — fast.

FULLUI is a powerful and lightweight **console UI framework for Python**, designed to transform boring CLI programs into visually rich experiences.

---

# ✨ Features

* 🎨 ANSI + RGB color system
* 🌈 Advanced gradients
* ✨ Text styling system
* 🧱 Decorative boxes & layouts
* 🎮 Flexible alias-based menu system
* ⚡ Terminal animations
* 🎭 Plug & Play Theme Engine
* 🛠️ Developer Tools Panel *(NEW)*
* 📦 Registry System *(NEW)*
* 🎬 Animation Preview System *(NEW)*
* 🎉 Welcome Banner System *(NEW)*
* 🧠 Modular architecture

---

# 🆕 New in v0.2.0

## Added

## 🛠 Developer Tools System

Built-in terminal tools for development:

```python
from fullui import system_panel
system_panel()
```

Includes:

* Themes Manager
* Color Inspector
* Animations Preview
* Registry Inspector
* System Info Panel

---

## 🎭 10 New Themes

```python
from fullui import set_theme, HACKER
set_theme(HACKER)
```

Available themes:

DEFAULT, DARK, NEON, FIRE, ICE

New:

HACKER, VOID, ELECTRIC, NIGHT, ALERT, FROST, NATURE, DEV, GAMER, BRUTAL

---

## 🎬 New Animations

```python
from fullui import *

loading_dots()
progress_fill()
typing("Hello World")
countdown()
success_check()
loading_bar_wave()
```

New effects:

* loading_dots()
* progress_fill()
* typing()
* countdown()
* success_check()
* loading_bar_wave()

---

## 🎨 Expanded Color System

```python
C.gold
C.neon_green
C.electric_blue
C.fire_orange
C.deep_pink
C.wine
```

RGB:

```python
print(rgb(255,120,0)+"Hello")
```

---

## 📦 Registry System

```python
register_theme("mytheme", my_theme)

register_color(
    "danger",
    rgb(255,0,0)
)

register_animation(
    "shake",
    my_animation
)
```

---

# 🎯 Perfect For

* Console games
* CLI tools
* Interactive terminal apps
* UI prototyping
* Terminal dashboards

---

# 📦 Installation

```bash
pip install fullui
```

## ✨ Verify Installation (Optional)

Show FULLUI welcome banner after install:

```bash
pip install fullui
python -c "import fullui; fullui.banner()"
```

Example:

```python
import fullui
fullui.banner()
```

Displays:

```text
███████╗██╗   ██╗██╗     ██╗     ██╗   ██╗██╗
...

🎨 FULLUI v0.2.0
Advanced Console UI Framework
✔ Installed successfully
```

---

# 🚀 Quick Start

```python
from fullui import *

banner()

menu(
    t="Main Menu",
    op=[
        "Play",
        "Settings"
    ]
)
```

---

# 🧩 Recommended Import Style

```python
from fullui.colors import C, S
from fullui.ui import menu

choice = menu(
    t="Menu",
    st="Choose",
    op=["Start","Exit"]
)
```

---

# 🧠 Menu Behavior

* Loops until valid input
* Returns int
* Invalid input handled automatically
* Returns None on exit

```python
choice = menu(
    t="Game",
    op=["Play","Settings"]
)

if choice == 1:
    print("Play")
elif choice is None:
    print("Exit")
```

---

# 🎨 Themes

```python
from fullui import *

set_theme(NEON)

menu(
 t="Styled Menu",
 op=["Option A","Option B"]
)
```

Custom:

```python
my_theme = create_theme(
    titleColor=C.r,
    inputColor=C.g
)

set_theme(my_theme)
```

---

# 🎨 Colors & Styles

```python
print(C.r+"Red"+S.rs)
print(S.bd+"Bold"+S.rs)
```

---

# 🧱 Boxes

```python
print(box1("Hello"))
print(box4("Warning"))
```

---

# 🌈 Gradients

```python
print(rainbow("FULLUI"))

print(
 customGra(
   "Gradient",
   C.r,
   C.g,
   C.b
 )
)
```

---

# 🎬 Animations

```python
spinner()
glitch("ERROR")
progress_fill()
loading_dots()
```

---

# 🖥 UI Alias System

```python
menu(
 t="Menu",
 st="Info",
 op=["A","B"]
)
```

Aliases:

t, st, op, bs, etc.

---

# 🔧 Utilities

```python
clear()
pause()
```

---

# 🧩 Full Import

```python
from fullui import *
```

Everything exposed through **all**.

---

# 🆕 Patch Notes — v0.2.0

## Major Features Added

## Developer Tools Suite

Added:

* system_panel()
* themes_manager()
* animations_preview()
* system_info()
* registry_inspector()

---

## Theme Engine Expanded

Added 10 new themes plus:

* titleColorMargins
* break key theming
* theme previews
* theme manager UI

---

## Animation Expansion

Added:

* loading_dots
* progress_fill
* typing
* countdown
* success_check
* loading_bar_wave

---

## Registry System Added

Supports:

* register_theme()
* register_color()
* register_animation()

---

## Welcome Banner Added

Added:

* banner()
* about() alias

Quick verification:

```bash
python -c "import fullui; fullui.banner()"
```

---

## Color System Expanded

Added:

* Gold
* Lime
* Neon Green
* Electric Blue
* Fire Orange
* Deep Pink
* Wine
* Steel Gray

---

## Improvements

* breakSimbol typo fixed -> breakSymbol
* Improved clear screen behavior
* Better title rendering
* Better theme contrast
* Improved menu exit behavior

---

## Behavior Changes

menu() exit now returns:

```python
None
```

instead of:

```python
"break"
```

---

# 🚀 Roadmap

* Keyboard navigation
* Panel layouts
* Real-time menus
* JSON themes
* State management
* Mouse terminal support

---

# 📄 License

MIT License

---

# 👨‍💻 Author

**Leonardo Farid Porras Bendezú**
aka **LeonardX007**
